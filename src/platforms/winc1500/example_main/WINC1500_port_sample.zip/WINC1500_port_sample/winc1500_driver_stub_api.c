
/**
  WINC1500 Driver Stub API Source File 

  @Company
    Microchip Technology Inc.

  @File Name
    winc1500_driver_stub_api.c

  @Summary
    Before one can use the WINC1500 Driver API, there are some MCU-specific stub 
    functions that must be coded. The WINC1500 Driver will call these functions 
    during run-time.

  @Description
    The function prototypes are provided using the MPLAB Code Configurator (MCC)
    Plug-in. The MLA Driver will call these functions, but they must be coded by 
    the user. The stub functions control MUC-specific hardware and event handling:
       - SPI Interface
       - GPIO control
       - 1ms Timer
       - Interrupt from WINC1500
       - Event handling for Wi-Fi, socket, and OTA events
 */

/*
    (c) 2016 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
 */

//==============================================================================
// INCLUDES
//==============================================================================    
#include "winc1500_api.h"
#include "winc1500_driver_api_helpers.h"

//==============================================================================
// GPIO Stub Functions:
// --------------------
//    - The WINC1500 driver needs to control three GPIO outputs to the WINC1500.
//      connected to WINC1500's Chip enable, Reset and SPI slave select.
//    - The GPIO's described in this section should be configured as outputs and 
//      defaulted high prior to the WINC1500 driver running.     
//==============================================================================

void m2mStub_PinSet_CE(t_m2mWifiPinAction action)
{
    if (action == M2M_WIFI_PIN_LOW)
    {
        // TODO: set WINC1500 chip enable pin low
    }
    else
    {
        // TODO: set WINC1500 chip enable pin high
    }
}

void m2mStub_PinSet_RESET(t_m2mWifiPinAction action)
{
    if (action == M2M_WIFI_PIN_LOW)
    {
        // TODO: set WINC1500 reset pin low
    }
    else
    {
        // TODO: set WINC1500 reset pin high
    }
}

void m2mStub_PinSet_SPI_SS(t_m2mWifiPinAction action)
{
    if (action == M2M_WIFI_PIN_LOW)
    {
        // TODO: set WINC1500 slave select pin low
    }
    else
    {
        // TODO: set WINC1500 slave select pin high
    }
}

//==============================================================================
// Interrupt Stub Functions:
// --------------------------
//    - The WINC1500 will interrupt the host MCU when events occur by setting the 
//      IRQN line low. 
//    - The Host MCU should be configured to trigger an interrupt on a falling edge.
//==============================================================================

void m2mStub_EintEnable(void)
{
    // TODO: Enable external interrupt connected to WINC1500
}

void m2mStub_EintDisable(void)
{
    // TODO: Disable external interrupt connected to WINC1500
}

//==============================================================================
// Timer Stub Functions:
// ---------------------
//    - The WINC1500 state machines require a timer with one millisecond resolution. 
//    - The timer is a 32-bit counter that counts up starting at 0x00000000 and 
//      wraps back to 0 after reaching 0xffffffff. 
//==============================================================================

// A TMR peripheral can be set to interrupt every 1ms. The timer ISR increments 
// a global counter.

static volatile uint32_t g_oneMsCounter = 0;

// TODO: 
// Implement this timer ISR or call this function in your timer ISR to
// increment g_oneMsCounter variable as below:
/* void TMR_ISR(void) 
{
    g_oneMsCounter++;
}  */

uint32_t m2mStub_GetOneMsTimer(void)
{
    uint32_t tmp;

    //TODO: disable timer interrupt
    tmp = g_oneMsCounter; // get a clean copy of counter variable 
    //TODO: enable timer interrupt back again

    return tmp;
}

//==============================================================================
// SPI Stub Functions:
// ---------------------
//    - The Host MCU will communicate to the WINC1500 via the SPI interface.
//==============================================================================

void m2mStub_SpiTxRx(uint8_t *p_txBuf,
                    uint16_t txLen,
                    uint8_t *p_rxBuf,
                    uint16_t rxLen)
{
    uint16_t byteCount;
    uint16_t i;
    
    /* total number of byte to clock is whichever is larger, txLen or rxLen */
    byteCount = (txLen >= rxLen) ? txLen : rxLen;

    for (i = 0; i < byteCount; ++i)
    {
        /* if still have bytes to transmit from tx buffer */
        if (txLen > 0)
        {
			// TODO: put actual data in SPI register as below
            //SPI1BUF = *p_txBuf++;
            --txLen;
        }
        /* else done writing bytes out from tx buffer */
        else
        {
			// TODO: put dummy data (0x00) in SPI register as below
            //SPI1BUF = 0x00; /* clock out a "don't care" byte */
        }
        
		// TODO: Implemet a wait() call for SPI to complete byte transfer/receive (MCU specific flags)
		// example for PIC microntroller as below:
		/* wait until tx/rx byte to completely clock out */
		//while ((SPI1STATbits.SPITBF == 1) || (SPI1STATbits.SPIRBF == 0))

        /* if still have bytes to read into rx buffer */
        if (rxLen > 0)
        {
			// TODO: read actual data from SPI register as below
            //*p_rxBuf++ = SPI1BUF;
            --rxLen;
        }
            /* else done reading bytes into rx buffer */
        else
        {
			// TODO: read dummy data from SPI register as below
            //SPI1BUF; /* read and throw away byte */
        }
    } /* end for loop */
}

//==============================================================================
// Event Stub Functions:
// ---------------------
//    These are callback functions that the WINC1500 host driver calls to notify 
//    the application of events. There are four categories of events:
//      - Wi-Fi events
//      - Socket events
//      - OTA (Over-The-Air) update events
//      - Error Events
//==============================================================================

volatile tpfAppWifiCb gpfAppWifiCb = NULL;

void registerWifiCallback(tpfAppWifiCb pfAppWifiCb)
{
    gpfAppWifiCb = pfAppWifiCb;
}

void m2m_wifi_handle_events(t_m2mWifiEventType eventCode, t_wifiEventData *p_eventData)
{
    if (gpfAppWifiCb)
        gpfAppWifiCb(eventCode, p_eventData);
    else
        printf("STUB_WIFI_EVENT[%d]: Wi-Fi event handler not registered!\r\n", eventCode);
}

//             --------------- * end of wifi event block * ---------------

volatile tpfAppSocketCb gpfAppSocketCb = NULL;

void registerSocketCallback(tpfAppSocketCb pfAppSocketCb)
{
    gpfAppSocketCb = pfAppSocketCb;
}

void m2m_socket_handle_events(SOCKET sock, t_m2mSocketEventType eventCode, t_socketEventData *p_eventData)
{
    if (gpfAppSocketCb)
        gpfAppSocketCb(sock, eventCode, p_eventData);
    else
        printf("STUB_SOCK_EVENT[%d]: Socket event handler not registered!\r\n", eventCode);
}

//             --------------- * end of socket event block * ---------------

void m2m_ota_handle_events(t_m2mOtaEventType eventCode, t_m2mOtaEventData *p_eventData)
{
    printf("STUB_OTA_EVENT[%d]: OTA event handler not registered!\r\n", eventCode);
}

void m2m_error_handle_events(uint32_t errorCode)
{
    printf("STUB_ERR_EVENT[x]: ERROR EVENT: %lu\n", errorCode);
}


#if defined(M2M_ENABLE_SPI_FLASH)

//==============================================================================
// Wi-Fi Console Functions:
// ---------------------
//    - Functions for firmware update utility
//    - Implement if necessary, otherwise leave blank.
//==============================================================================
void m2m_wifi_console_write_data(uint16_t length, uint8_t *p_buf)
{
    // uint16_t i;
    
    // for (i = 0; i < length; i++)
    // {
    //     console_byte_write(p_buf[i]);
    // }
}

uint8_t m2m_wifi_console_read_data(void)
{	
    //return console_byte_read();
}

bool m2m_wifi_console_is_read_data(void)
{
	// true => Receive buffer has data, at least one more character can be read from console
    // false => Receive buffer is empty
    // return isConsoleDataAvaiable();
}

#endif // M2M_ENABLE_SPI_FLASH